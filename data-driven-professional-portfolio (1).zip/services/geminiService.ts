import { GoogleGenAI } from "@google/genai";

export const getAIProjectInsight = async (projectTitle: string, userQuestion: string) => {
  // Initialize right before call as per performance and safety guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Context: You are "LouiseAI", a professional assistant for Louise's portfolio. 
      Louise is a high-achieving Marketing and Supply Chain Analyst with a global background.
      Current Project: ${projectTitle}. 
      User Question: ${userQuestion}
      Instruction: 
      1. Provide a grounded, expert-level response that highlights Louise's analytical rigor.
      2. Mention specific frameworks if relevant (e.g., ELM, Hayes PROCESS, Bayesian modeling).
      3. Maintain a calm, minimalist tone. Keep it under 80 words.`,
    });
    return response.text || "I'm sorry, I couldn't generate an insight at this moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "The AI assistant is currently resting. Please try again later.";
  }
};